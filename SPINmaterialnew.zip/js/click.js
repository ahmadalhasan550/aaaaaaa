var buka = new Audio();
buka.src = "https://e.top4top.io/m_1839g790y1.mp3";

var tutup = new Audio();
tutup.src = "https://k.top4top.io/m_1807x9v082.mp3";